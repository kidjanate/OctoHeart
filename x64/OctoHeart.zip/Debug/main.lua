function Start()
    Window.SetTitle("OwO, I'm title")
    Window.SetSize(512,512)
    Window.ShowConsole()
end

function Update()

end