function Start()
    Window.ShowConsole()
end

function OnKeyDown(key)
    if key == Input.KeyCode.W then
        print("W pressed")
    end

    if key == Input.KeyCode.A then
        print("A pressed")
    end

    if key == Input.KeyCode.S then
        print("S pressed")
    end

    if key == Input.KeyCode.D then
        print("D pressed")
    end
end

function OnKeyUp(key)
    if key == Input.KeyCode.W then
        print("W up")
    end

    if key == Input.KeyCode.A then
        print("A up")
    end

    if key == Input.KeyCode.S then
        print("S up")
    end

    if key == Input.KeyCode.D then
        print("D up")
    end
end
